/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 pic3 pic3.png 
 * Time-stamp: Saturday 03/30/2024, 05:56:42
 * 
 * Image Information
 * -----------------
 * pic3.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIC3_H
#define PIC3_H

extern const unsigned short pic3[400];
#define PIC3_SIZE 800
#define PIC3_LENGTH 400
#define PIC3_WIDTH 20
#define PIC3_HEIGHT 20

#endif

