/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 pic1 pic1.png 
 * Time-stamp: Friday 03/29/2024, 20:45:22
 * 
 * Image Information
 * -----------------
 * pic1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIC1_H
#define PIC1_H

extern const unsigned short pic1[38400];
#define PIC1_SIZE 76800
#define PIC1_LENGTH 38400
#define PIC1_WIDTH 240
#define PIC1_HEIGHT 160

#endif

