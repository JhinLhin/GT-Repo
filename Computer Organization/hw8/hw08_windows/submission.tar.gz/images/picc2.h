/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 picc2 picc2.png 
 * Time-stamp: Saturday 03/30/2024, 06:06:02
 * 
 * Image Information
 * -----------------
 * picc2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PICC2_H
#define PICC2_H

extern const unsigned short picc2[38400];
#define PICC2_SIZE 76800
#define PICC2_LENGTH 38400
#define PICC2_WIDTH 240
#define PICC2_HEIGHT 160

#endif

