/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x40 pic4 pic4.jpg 
 * Time-stamp: Saturday 03/30/2024, 05:37:06
 * 
 * Image Information
 * -----------------
 * pic4.jpg 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIC4_H
#define PIC4_H

extern const unsigned short pic4[1600];
#define PIC4_SIZE 3200
#define PIC4_LENGTH 1600
#define PIC4_WIDTH 40
#define PIC4_HEIGHT 40

#endif

