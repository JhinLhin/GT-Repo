/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 pic2 pic2.png 
 * Time-stamp: Saturday 03/30/2024, 04:51:39
 * 
 * Image Information
 * -----------------
 * pic2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIC2_H
#define PIC2_H

extern const unsigned short pic2[38400];
#define PIC2_SIZE 76800
#define PIC2_LENGTH 38400
#define PIC2_WIDTH 240
#define PIC2_HEIGHT 160

#endif

