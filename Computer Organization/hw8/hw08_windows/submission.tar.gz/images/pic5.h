/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x40 pic5 pic5.png 
 * Time-stamp: Saturday 03/30/2024, 14:47:40
 * 
 * Image Information
 * -----------------
 * pic5.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIC5_H
#define PIC5_H

extern const unsigned short pic5[1600];
#define PIC5_SIZE 3200
#define PIC5_LENGTH 1600
#define PIC5_WIDTH 40
#define PIC5_HEIGHT 40

#endif

